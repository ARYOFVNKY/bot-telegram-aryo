const fs = require("fs");
const path = require("path");
const { Api } = require("telegram");
const archiver = require("archiver");
const { Client: SSHClient } = require("ssh2");
const axios = require("axios");

module.exports = async (client, msg) => {
try {
let sellerList = JSON.parse(fs.readFileSync("./data-sellerlist.json"));
let blacklist = JSON.parse(fs.readFileSync("./data-blacklist.json"));
const isCmd = msg.message?.startsWith(global.prefix);
const args = msg.message.trim().split(/ +/).slice(1);
const argText = text = args.join(" ");
const command = isCmd ? msg.message.slice(global.prefix.length).trim().split(" ").shift().toLowerCase() : "";
const cmd = global.prefix + command;
const chatId = msg.chatId;
const me = await client.getMe();
const isSeller = sellerList.includes(msg.senderId.toString())
const isOwner =
  (msg?.fromId?.userId.toString() || msg.senderId?.toString()) === global.ownerID?.toString() ||
  msg.senderId?.toString() === me.id.toString();
  
const reply = async (message, options = {}) => {
  try {
    const payload = {
      message,
      replyTo: msg.id,
      parseMode: "html",
      linkPreview: false,
      ...options,
    };
    return await client.sendMessage(options.jid ? options.jid : msg.chatId, payload);
  } catch (err) {
    console.error("Reply error:", err?.message || err);
  }
};

const messOwner = () => reply("⚠️ Hanya Owner yang bisa menggunakan perintah ini!");
const messGroup = () => reply("⚠️ Perintah ini hanya bisa dijalankan di dalam grup.");

if (global.modeSelf && !isOwner) return

switch (command) {
case "menu":
case "help":
case "start": {
  const userId = msg.senderId; // ambil ID user
  const name = msg.sender?.firstName || "User";

  const menu = `
👋 Hii <a href="tg://user?id=${userId}">${name}</a>!
Saya adalah <b>Nintzy Simple Bot</b>, sebuah asisten Telegram yang dirancang untuk membantu Anda menjalankan berbagai perintah secara cepat, mudah, dan efisien ⚡

──────────────────────
<b>🤖 — Bot Information</b>
• Dev: Nintzy Ubot
• Runtime: <b>${runtime(process.uptime())}</b>
• Mode: <b>${global.modeSelf ? "Self" : "Public"}</b>

──────────────────────
<b>👑 — {Owner Menu} </b>
${global.prefix}bc
${global.prefix}cfd
${global.prefix}listgc
${global.prefix}enc
${global.prefix}bl
${global.prefix}delbl
${global.prefix}listbl
${global.prefix}resetbl
${global.prefix}pushkontak
${global.prefix}pay
${global.prefix}proses - .done
${global.prefix}backup
${global.prefix}eval

🅂🅄🄿🄿🄾🅁🅃 🄱🅈 🄽🄸🄽🅃🅉🅈 🅄🄱🄾🅃
───────────────────────────────
<b>🧩 — Panel Menu</b>
${global.prefix}1gb - .unlimited
${global.prefix}listpanel
${global.prefix}delpanel
${global.prefix}cadmin
${global.prefix}listadmin
${global.prefix}deladmin
${global.prefix}addseller
${global.prefix}listseller
${global.prefix}resetseller
${global.prefix}delseller
${global.prefix}installpanel
${global.prefix}subdomain

───────────────────────────────
<b>⚙️ — Settingbot Menu</b>
${global.prefix}setprefix

🅂🅄🄿🄿🄾🅁🅃 🄽🄸🄽🅃🅉🅈 🅄🄱🄾🅃
`;

  await client.sendFile(msg.chatId, {
    file: global.thumbnail,
    caption: menu,
    replyTo: msg.id,
    parseMode: "html",
  });
}
break;

case "ping": {
  const os = require("os");
  const nou = require("node-os-utils");
  const speed = require("performance-now");

  const start = speed();

  const cpu = nou.cpu;
  const drive = nou.drive;
  const mem = nou.mem;
  const netstat = nou.netstat;

  // Ambil data paralel
  const [osName, driveInfo, memInfo, cpuUsage, netStats] = await Promise.all([
    nou.os.oos().catch(() => "Unknown"),
    drive.info().catch(() => ({ usedGb: "N/A", totalGb: "N/A" })),
    mem.info().catch(() => ({ totalMemMb: 0, usedMemMb: 0, freeMemMb: 0 })),
    cpu.usage().catch(() => 0),
    netstat.inOut().catch(() => ({ total: null }))
  ]);

  const totalGB = (memInfo.totalMemMb / 1024 || 0).toFixed(2);
  const usedGB = (memInfo.usedMemMb / 1024 || 0).toFixed(2);
  const freeGB = (memInfo.freeMemMb / 1024 || 0).toFixed(2);

  // Pastikan data CPU tersedia
  const cpuList = os.cpus() || [];
  const cpuModel = cpuList[0]?.model || "Unknown CPU";
  const cpuSpeed = cpuList[0]?.speed || "N/A";
  const cpuCores = cpuList.length || 0;

  const vpsUptime = runtime(os.uptime());
  const botUptime = runtime(process.uptime());
  const latency = (speed() - start).toFixed(2);
  const loadAvg = os.loadavg().map(n => n.toFixed(2)).join(" | ");
  const nodeVersion = process.version;
  const platform = os.platform();
  const hostname = os.hostname();
  const arch = os.arch();
  const network = netStats.total
    ? `${netStats.total.inputMb.toFixed(2)} MB ↓ / ${netStats.total.outputMb.toFixed(2)} MB ↑`
    : "N/A";

  const tt = `
<b>⚙️ SYSTEM STATUS</b>
<b>• OS :</b> ${nou.os.type()} (${osName})
<b>• Platform :</b> ${platform.toUpperCase()}
<b>• Arch :</b> ${arch}
<b>• Hostname :</b> ${hostname}

<b>💾 STORAGE</b>
<b>• Disk :</b> ${driveInfo.usedGb}/${driveInfo.totalGb} GB
<b>• RAM :</b> ${usedGB}/${totalGB} GB (Free: ${freeGB} GB)

<b>🧠 CPU INFO</b>
<b>• Model :</b> ${cpuModel}
<b>• Core(s) :</b> ${cpuCores}
<b>• Speed :</b> ${cpuSpeed} MHz
<b>• Usage :</b> ${cpuUsage.toFixed(2)}%
<b>• Load Avg :</b> ${loadAvg}

<b>🤖 BOT STATUS</b>
<b>• Response Time :</b> ${latency} sec
<b>• Bot Uptime :</b> ${botUptime}
<b>• VPS Uptime :</b> ${vpsUptime}
<b>• Node.js :</b> ${nodeVersion}
`;

await client.sendMessage(msg.chatId, {
    message: tt,
    parseMode: "html",
    replyTo: msg.id
  });
}
break;


case "enc": {
  if (!isOwner) return messOwner()
  const jsconfuser = await import("js-confuser");
  const chatId = msg.chatId;

  if (!msg.replyTo) {
    return client.sendMessage(chatId, {
      message: "Reply file `.js` untuk dienkripsi!",
      replyTo: msg.id,
    });
  }

  const repl = await msg.getReplyMessage()
  const file = repl.media;

  if (!file || !repl.media.document || !repl.media.document.attributes[0].fileName.endsWith(".js")) {
    return client.sendMessage(chatId, {
      message: "Hanya bisa untuk file `.js`",
      replyTo: msg.id,
    });
  }

  await client.sendMessage(chatId, {
    message: `🔒 Sedang memproses encrypt ${repl.media.document.attributes[0].fileName}...`,
    replyTo: msg.id,
  });

  try {
    // Unduh file sebagai buffer
    const buffer = await client.downloadMedia(repl.media);
    if (!buffer) {
      return client.sendMessage(chatId, {
        message: "Gagal download file!",
        replyTo: msg.id,
      });
    }

    const inputCode = buffer.toString();
    const encryptedCode = await jsconfuser.obfuscate(inputCode, {
      target: "node",
      preset: "high",
      stringEncoding: true,
      identifierGenerator: "zeroWidth",
    });

    const outPath = `./${repl.media.document.attributes[0].fileName}`;
    fs.writeFileSync(outPath, encryptedCode.code);

    await client.sendFile(chatId, {
      file: outPath,
      caption: `✅ Berhasil encrypt file ${repl.media.document.attributes[0].fileName}`,
      replyTo: msg.id,
    });

    fs.unlinkSync(outPath);
  } catch (err) {
    if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
    console.error("Gagal mengenkripsi:", err);
    await client.sendMessage(chatId, {
      message: "Terjadi kesalahan saat encrypt file!",
      replyTo: msg.id,
    });
  }
}
break;

case "setprefix": {
  if (!isOwner) return messOwner()
  if (!args[0]) return reply(`Masukkan prefix baru!\n\nContoh:\n${cmd} !`)

  const newPrefix = args[0].trim()
  if (newPrefix.length > 1) return reply("Prefix terlalu panjang (maksimal 1 karakter).")

  let configFile = fs.readFileSync("./settings.js", "utf-8")

  // Ubah nilai global.prefix di settings.js
  configFile = configFile.replace(
    /global\.prefix\s*=\s*(['"`]).*?\1/,
    `global.prefix = '${newPrefix}'`
  )

  fs.writeFileSync("./settings.js", configFile, "utf-8")
  global.prefix = newPrefix

  reply(`✅ Prefix berhasil diubah menjadi: <b>${newPrefix}</b>`)
}
break;

case "self": {
  if (!isOwner) return messOwner()
  if (global.modeSelf) return reply("Bot sudah dalam mode Self ✅")

  global.modeSelf = true

  let configFile = fs.readFileSync("./settings.js", "utf-8")
  configFile = configFile.replace(
    /global\.modeSelf\s*=\s*(true|false)/,
    "global.modeSelf = true"
  )
  fs.writeFileSync("./settings.js", configFile, "utf-8")

  reply("🔒 Bot sekarang dalam mode Self")
}
break;

case "public": {
  if (!isOwner) return messOwner()
  if (!global.modeSelf) return reply("Bot sudah dalam mode Public ✅")

  global.modeSelf = false

  let configFile = fs.readFileSync("./settings.js", "utf-8")
  configFile = configFile.replace(
    /global\.modeSelf\s*=\s*(true|false)/,
    "global.modeSelf = false"
  )
  fs.writeFileSync("./settings.js", configFile, "utf-8")

  reply("🔓 Bot sekarang dalam mode Public")
}
break;

case "tourl": {
  let targetMessage
  if (msg.replyToMsgId) {
    try {
      const replied = await msg.getReplyMessage()
      if (replied) {
        targetMessage = replied
      }
    } catch (error) {
      console.error("Gagal mengambil pesan yang dibalas:", error.message)
    }
  }

  const msgMedia = targetMessage?.media
  
  if (!msgMedia) {
    return reply("Reply media (foto, video, atau dokumen) untuk menggunakannya.")
  }
  let buffer
  try {
    buffer = await targetMessage.downloadMedia({
      downloadUrl: false
    })
  } catch (error) {
    console.error("Gagal mendownload media:", error.message)
    return reply("❌ Gagal mendownload media.")
  }

  if (!buffer) {
    return reply("❌ Gagal mendapatkan data buffer dari media.")
  }

  const FormData = (await import("form-data")).default
  const { fileTypeFromBuffer } = await import("file-type")
  const fetchModule = await import("node-fetch")
  const fetch = fetchModule.default

  async function uploadToCatbox(buf) {
    let { ext } = await fileTypeFromBuffer(buf)
    let bodyForm = new FormData()
    bodyForm.append("fileToUpload", buf, "file." + ext)
    bodyForm.append("reqtype", "fileupload")
    
    let res = await fetch("https://catbox.moe/user/api.php", {
      method: "POST",
      body: bodyForm
    })
    
    let data = await res.text()
    return data
  }

  try {
    const url = await uploadToCatbox(buffer)
    await reply(`✅ Media berhasil diupload:\n${url}`)
  } catch (error) {
    console.error("Gagal upload ke Catbox:", error.message)
    await reply("❌ Terjadi kesalahan saat mengupload media.")
  }
}
break

case "me": {
  const sender = await client.getEntity(msg.senderId);
  const info = `
🆔 ID: <code>${sender.id}</code>
📛 Nama: <b>${sender.firstName || ""} ${sender.lastName || ""}</b>
👤 Username: @${sender.username || "-"}
🌐 Bot: ${sender.bot ? "Ya" : "Tidak"}
✅ Premium: ${sender.premium ? "Ya" : "Tidak"}
`;
  await reply(info);
  break;
}

case "listgc": {
  if (!isOwner) return messOwner()
  await reply("<b>⚙️ Mengambil daftar grup & channel...</b>");
  const dialogs = await client.getDialogs();
  const targets = dialogs.filter((d) => d.isGroup || d.isChannel);
  if (targets.length === 0) return reply("<b>⚠️ Tidak ada grup atau channel ditemukan.</b>");
  let list = "<b>Daftar Grup/Channel:</b>\n\n";
  targets.forEach((d, i) => {
    list += `${i + 1}. ${d.name || "(Tanpa Nama)"} - <code>${d.id}</code>\n`;
  });
  await client.sendMessage(msg.chatId, { message: list, parseMode: "html", replyTo: msg.id });        
  break;
}

case "bl": {
  if (!isOwner) return messOwner()
  if (!msg.isGroup) return messGroup()
  const groupId = msg.chatId.toString();
  const group = await client.getEntity(chatId);
  if (blacklist.includes(groupId)) return reply(`⚠️ Grup <b>${group.title}</b> sudah ada di blacklist.`);
  blacklist.push(groupId);
  await fs.writeFileSync("./data-blacklist.json", JSON.stringify(blacklist, null, 2))
  await reply(`✅ Grup <b>${group.title}</b> berhasil ditambahkan ke blacklist.`);
  break;
}

case "delbl": {
  if (!isOwner) return messOwner()
  if (!msg.isGroup) return messGroup()
  const groupId = msg.chatId.toString();
  const group = await client.getEntity(chatId);
  if (!blacklist.includes(groupId)) return reply(`⚠️ Grup <b>${group.title}</b> tidak ada di blacklist.`);
  blacklist = blacklist.filter((id) => id !== groupId);
  await fs.writeFileSync("./data-blacklist.json", JSON.stringify(blacklist, null, 2))
  await reply(`✅ Grup <b>${group.title}</b> dihapus dari blacklist.`);
  break;
}

case "listbl": {
  if (!isOwner) return messOwner()
  if (blacklist.length === 0) return reply("Tidak ada grup dalam blacklist.");
  let txt = "\n";
  for (const [i, id] of blacklist.entries()) {
    try {
      const group = await client.getEntity(id);
      txt += `${i + 1}. ${group.title} (<code>${id}</code>)\n`;
    } catch {
      txt += `${i + 1}. [Tidak diketahui] (<code>${id}</code>)\n`;
    }
  }
  await reply(txt);
  break;
}

case "resetbl": {
  if (!isOwner) return messOwner()
  blacklist = [];
  await fs.writeFileSync("./data-blacklist.json", JSON.stringify(blacklist, null, 2))
  await reply("✅ Semua grup dalam blacklist telah dihapus.");
  break;
}

case "bc": {
  if (!isOwner) return messOwner()
  if (!argText) return reply(`Masukan teks broadcast!\n\nContoh penggunaan:\n<code>${cmd}</code> teks`);       
  const dialogs = await client.getDialogs();
  const targets = dialogs.filter((d) => (d.isGroup || d.isChannel) && !blacklist.includes(d.id.toString()));
  await reply(`📢 <b>Mulai mengirim broadcast ke ${targets.length} grup & channel...</b>`);
  let sukses = 0, gagal = 0;
  for (const d of targets) {
    try {
      await client.sendMessage(d.id, { message: argText, parseMode: "html" });
      sukses++;
    } catch (e) {
      gagal++;
    }
    await sleep(1000);
  }
  await reply(`✅ <b>Broadcast selesai!</b>\n\nSukses: ${sukses}\nGagal: ${gagal}\nBlacklist: ${blacklist.length}`);
  break;
}

case "cfd": {
  if (!isOwner) return messOwner()
  if (!msg.replyToMsgId) return reply(`Reply pesannya!\n\nContoh penggunaan:\n<code>${cmd}</code> dengan reply pesan`);       
  const replied = await msg.getReplyMessage();
  if (!replied) return reply("⚠️Tidak dapat menemukan pesan yang dibalas.");
  const dialogs = await client.getDialogs();
  const peerFrom = replied.fwdFrom && replied.fwdFrom.fromId.className == "PeerChannel" ? replied.fwdFrom.fromId : replied.chat
  const targets = dialogs.filter((d) => (d.isGroup || d.isChannel) && !blacklist.includes(d.id.toString()));
  await reply(`🔁 <b>Forward pesan ke ${targets.length} grup/channel...</b>`);
  let sukses = 0, gagal = 0;
  for (const d of targets) {
    try {
      await client.forwardMessages(d.id, { messages: [replied.id], fromPeer: replied.chat });
      sukses++;
    } catch (e) {
      gagal++;
      console.log(`[•] Fwd ${d.title} Error: ${e}`)
    }
    await sleep(1000);
  }
  await reply(`✅ <b>Forward selesai!</b>\n\nSukses: ${sukses}\nGagal: ${gagal}\nBlacklist: ${blacklist.length}`);
  break;
}

case "pushkontak": {
  if (!isOwner) return messOwner()
  if (!msg.isGroup) return messGroup()
  const replied = await msg.getReplyMessage();
  if (!replied) return reply(`Reply pesannya!\n\nContoh penggunaan:\n<code>${cmd}</code> dengan reply pesan`); 
  try {
    const groupEntity = await client.getEntity(msg.chatId);
    const participants = await client.getParticipants(groupEntity);
    await reply(`<b>⏳ Memulai forward pesan ke ${participants.length} anggota grup...</b>`);
    let sentCount = 0;
    for (const user of participants) {
      if (user.bot || !user.id) continue;
      try {
        await client.forwardMessages(user.id, { fromPeer: msg.chatId, id: [replied.id] });
        sentCount++;
      } catch (err) {
        console.log(`Gagal forward ke ${user.id}:`, err?.message || err);
      }
      await sleep(2000);
    }
    await reply(`<b>✅ Selesai forward ke ${sentCount} anggota grup!</b>`);
  } catch (err) {
    console.error("pushkontak error:", err);
    await reply("<b>❌ Terjadi kesalahan saat menjalankan pushkontak.</b>");
  }
  break;
}

case "pay":
case "payment": {
  if (!global.dana && !global.ovo && !global.gopay && !global.qris)
    return reply("<b>⚠️ Informasi pembayaran belum dikonfigurasi.</b>");
  try {
    const paymentList = `
<blockquote><b>Dana :</b></blockquote> <code>${global.dana || "-"}</code>

<blockquote><b>Ovo :</b></blockquote> <code>${global.ovo || "-"}</code>

<blockquote><b>Gopay :</b></blockquote> <code>${global.gopay || "-"}</code>

<blockquote>Wajib kirimkan bukti transfer demi keamanan bersama.</blockquote>
`;
    const Url = global.qris && global.qris.includes("https://") ? global.qris : "https://files.catbox.moe/wri0uz.jpg";
    await client.sendFile(msg.chatId, { file: Url, caption: paymentList, replyTo: msg.id, parseMode: "html" });
  } catch (err) {
    console.error("pay error:", err);
    await reply("❌ Gagal mengirimkan informasi pembayaran.");
  }
  break;
}

case "done":
case "don": {
if (!isOwner) return messOwner()
if (!argText) return reply(`Masukan teks transaksi!\n\nContoh penggunaan:\n<code>${cmd}</code> Jasa Fix Error`)
const teks = `
<blockquote><b>Transaksi Done ✅</b></blockquote>

📦 <b>Pembelian:</b> ${argText}
🗓️ <b>Tanggal:</b> ${global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString()}

📢 <b>Cek Testimoni Pembeli:</b>
${global.linkChannel ? global.linkChannel : "-"}
`
try {
if (msg.replyToMsgId) {
await client.editMessage(msg.chatId, {
message: msg.replyToMsgId,
text: teks,
parseMode: "html",
linkPreview: false
})
} else {
await client.sendMessage(msg.chatId, {
message: teks,
parseMode: "html",
linkPreview: false
})
}
} catch (err) {
console.error("done error:", err)
await reply("❌ Gagal mengedit atau mengirim pesan konfirmasi transaksi.")
}
break
}

case "proses":
case "ps": {
if (!isOwner) return messOwner()
if (!argText) return reply(`Masukan teks transaksi!\n\nContoh penggunaan:\n<code>${cmd}</code> Jasa Fix Error`)
const teks = `
<blockquote><b>Dana Telah Diterima ✅</b></blockquote>

📦 <b>Pembelian:</b> ${argText}
🗓️ <b>Tanggal:</b> ${global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString()}

📢 <b>Cek Testimoni Pembeli:</b>
${global.linkChannel ? global.linkChannel : "-"}
`
try {
if (msg.id) {
await client.editMessage(msg.chatId, {
message: msg.id,
text: teks,
parseMode: "html",
linkPreview: false
})
} else {
await client.sendMessage(msg.chatId, {
message: teks,
parseMode: "html",
linkPreview: false
})
}
} catch (err) {
console.error("proses error:", err)
await reply("❌ Gagal mengedit atau mengirim pesan konfirmasi transaksi.")
}
break
}

case "backupsc":
case "bck":
case "backup": {
  if (!isOwner) return messOwner()
  try {
    await reply("⏳ <b>Memproses Backup Script...</b>");
    const bulanIndo = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
    const tgl = new Date();
    const tanggal = tgl.getDate().toString().padStart(2, "0");
    const bulan = bulanIndo[tgl.getMonth()];
    const name = `SimpleUbot-${tanggal}-${bulan}-${tgl.getFullYear()}`;

    const exclude = ["node_modules","package-lock.json","yarn.lock",".npm",".cache"];
    const filesToZip = fs.readdirSync(".").filter((f) => !exclude.includes(f) && f !== "");

    if (!filesToZip.length) return reply("❌ <b>Tidak ada file yang dapat di-backup.</b>");

    const output = fs.createWriteStream(`./${name}.zip`);
    const archive = archiver("zip", { zlib: { level: 9 } });
    archive.pipe(output);

    for (let file of filesToZip) {
      const stat = fs.statSync(file);
      if (stat.isDirectory()) archive.directory(file, file);
      else archive.file(file, { name: file });
    }

    await archive.finalize();

    output.on("close", async () => {
      try {
        await client.sendFile(global.ownerID, { file: `./${name}.zip`, caption: "✅ <b>Backup Script selesai!</b>", parseMode: "html" });
        fs.unlinkSync(`./${name}.zip`);
        if (msg.chatId.toString() !== global.ownerID?.toString()) {
          await client.sendMessage(msg.chatId, { message: "✅ <b>Backup script selesai!</b>\nFile telah dikirim ke chat pribadi.", replyTo: msg.id, parseMode: "html" });
        }
      } catch (err) {
        console.error("Gagal kirim file backup:", err);
        await reply("❌ <b>Gagal mengirim file backup ke chat pribadi.</b>");
      }
    });
  } catch (err) {
    console.error("Backup Error:", err);
    await reply("❌ <b>Terjadi kesalahan saat melakukan backup.</b>");
  }
  break;
}


case "1gb": case "2gb": case "3gb": case "4gb": case "5gb":
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb":
case "unlimited": case "unli": {
  if (!isOwner && !isSeller) return messOwner()
  if (!argText) return reply(`Masukan username!\n\nContoh penggunaan:\n<code>${cmd}</code> skyzopedia`);       

  const username = argText.toLowerCase();
  const email = `${username}@gmail.com`;
  const name = `${global.capital ? global.capital(username) : username} Server`;
  const password = `${username}001`;

  const resourceMap = {
    "1gb": { ram: "1000", disk: "1000", cpu: "40" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220" },
    "unlimited": { ram: "0", disk: "0", cpu: "0" }
  };

  const { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

  try {
    // create user
    const f = await fetch(`${global.domain}/api/application/users`, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` },
      body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
    });
    const data = await f.json();
    if (data.errors) return reply("❌ <b>Error:</b> " + JSON.stringify(data.errors[0], null, 2));
    const user = data.attributes;

    // get egg startup
    const f1 = await fetch(`${global.domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
      method: "GET",
      headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
    });
    const data2 = await f1.json();
    const startup_cmd = data2.attributes?.startup || "npm start";

    // create server
    const f2 = await fetch(`${global.domain}/api/application/servers`, {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` },
      body: JSON.stringify({
        name,
        description: global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString(),
        user: user.id,
        egg: parseInt(global.egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: startup_cmd,
        environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
        limits: { memory: ram, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 5, backups: 5, allocations: 5 },
        deploy: { locations: [parseInt(global.loc)], dedicated_ip: false, port_range: [] },
      })
    });
    const result = await f2.json();
    if (result.errors) return reply("❌ <b>Error:</b> " + JSON.stringify(result.errors[0], null, 2));
    const server = result.attributes;

    // domain spoiler (HTML <spoiler>)
    const domainTeks = (global.domain || "").replace(/https?:\/\//g, "");
    const tampilDomain = `<spoiler>${domainTeks}</spoiler>`;

    const teks = `
✅ <b>Berhasil membuat akun panel</b>

📡 <b>Server ID:</b> <code>${server.id}</code>
👤 <b>Username:</b> <code>${user.username}</code>
🔐 <b>Password:</b> <code>${password}</code>
🗓️ <b>Tanggal Aktivasi:</b> ${global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString()}

⚙️ <b>Spesifikasi server panel:</b>
- RAM: ${ram === "0" ? "Unlimited" : ram / 1000 + "GB"}
- Disk: ${disk === "0" ? "Unlimited" : disk / 1000 + "GB"}
- CPU: ${cpu === "0" ? "Unlimited" : cpu + "%"}
- Panel: ${tampilDomain}

📝 <b>Rules pembelian panel:</b>
- Masa aktif 30 hari
- Data bersifat pribadi, simpan dengan aman
- Garansi berlaku 15 hari (1x replace)
- Klaim garansi wajib menyertakan bukti chat pembelian
`;

    // send result: if invoked in group -> send notice to group + details via private message to sender
    const chatTarget = msg.isGroup ? msg.senderId : msg.chatId;
    if (msg.isGroup) {
      await reply("✅ <b>Berhasil membuat akun panel!</b>\n📩 Data akun telah dikirim ke private chat.");
    }
    await client.sendMessage(chatTarget, { message: teks, parseMode: "html", linkPreview: false });
  } catch (err) {
    console.error("create panel error:", err);
    await reply("❌ <b>Terjadi kesalahan saat membuat panel:</b> " + (err?.message || err));
  }
  break;
}

case "listpanel":
case "listserver": {
  if (!isOwner && !isSeller) return messOwner()
  try {
    const response = await fetch(`${global.domain}/api/application/servers`, {
      method: "GET",
      headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
    });
    const result = await response.json();
    const servers = result.data || [];
    if (servers.length === 0) return reply("⚠️ <b>Tidak ada server panel!</b>");

    let teks = `<b>Total server panel:</b> ${servers.length}\n`;
    for (const server of servers) {
      const s = server.attributes;
      const ram = s.limits.memory === 0 ? "Unlimited" : (s.limits.memory >= 1024 ? `${Math.floor(s.limits.memory / 1024)} GB` : `${s.limits.memory} MB`);
      const disk = s.limits.disk === 0 ? "Unlimited" : (s.limits.disk >= 1024 ? `${Math.floor(s.limits.disk / 1024)} GB` : `${s.limits.disk} MB`);
      const cpu = s.limits.cpu === 0 ? "Unlimited" : `${s.limits.cpu}%`;
      teks += `
• <b>ID:</b> <code>${s.id}</code>
• <b>Nama Server:</b> ${s.name}
• <b>RAM:</b> ${ram}
• <b>Disk:</b> ${disk}
• <b>CPU:</b> ${cpu}
• <b>Dibuat:</b> ${s.created_at?.split("T")[0] || "-"}\n`;
    }
    await client.sendMessage(msg.chatId, { message: teks, parseMode: "html", replyTo: msg.id });
  } catch (err) {
    console.error("Error listing panel servers:", err);
    await reply("⚠️ <b>Terjadi kesalahan saat mengambil data server.</b>");
  }
  break;
}

case "delpanel": {
  if (!isOwner && !isSeller) return messOwner()
  if (!argText) return reply(`Input ID Server!\n\nContoh penggunaan:\n<code>${cmd}</code> 13`);       

  const ids = argText.split(",").map(id => id.trim()).filter(Boolean);

  try {
    const [serverRes, userRes] = await Promise.all([
      fetch(`${global.domain}/api/application/servers`, {
        method: "GET",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
      }),
      fetch(`${global.domain}/api/application/users`, {
        method: "GET",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
      })
    ]);

    const serverData = await serverRes.json();
    const userData = await userRes.json();
    const servers = serverData.data || [];
    const users = userData.data || [];

    if (!servers.length) return reply("⚠️ <b>Tidak ada server yang ditemukan!</b>");

    let resultMsg = "\n";

    for (const id of ids) {
      const server = servers.find(s => s.attributes.id === Number(id));
      if (!server) {
        resultMsg += `❌ <b>ID ${id}:</b> Tidak ditemukan.\n`;
        continue;
      }

      const s = server.attributes;
      const serverName = s.name;
      const serverSection = s.name.toLowerCase();

      try {
        const delServer = await fetch(`${global.domain}/api/application/servers/${s.id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
        });

        if (!delServer.ok) {
          resultMsg += `⚠️ <b>ID ${id}:</b> Gagal hapus server (${serverName}).\n`;
          continue;
        }

        // remove associated user (match by first_name lowercased)
        const user = users.find(u => u.attributes.first_name && u.attributes.first_name.toLowerCase() === serverSection);
        if (user) {
          await fetch(`${global.domain}/api/application/users/${user.attributes.id}`, {
            method: "DELETE",
            headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
          });
        }

        resultMsg += `✅ <b>ID ${id}:</b> Berhasil hapus server <b>${global.capital ? global.capital(serverName) : serverName}</b>.\n`;
      } catch (err) {
        console.error(`Gagal hapus server ID ${id}:`, err);
        resultMsg += `❌ <b>ID ${id}:</b> Terjadi error internal.\n`;
      }
    }

    await client.sendMessage(msg.chatId, { message: resultMsg.trim(), parseMode: "html", replyTo: msg.id });
  } catch (err) {
    console.error("Error dalam proses delpanel:", err);
    await reply("❌ <b>Terjadi kesalahan saat memproses permintaan.</b>");
  }
  break;
}
      
case "cadmin": {
  if (!isOwner) return messOwner()
  if (!argText) return reply(`Masukan username!\n\nContoh penggunaan:\n<code>${cmd}</code> skyzopedia`);       

  const username = argText.toLowerCase();
  const email = `${username}@gmail.com`;
  const name = username.charAt(0).toUpperCase() + username.slice(1);
  const password = `${username}001`;
  const chatTarget = msg.isGroup ? msg.senderId : msg.chatId;

  try {
    const res = await fetch(`${global.domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${global.apikey}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: name,
        last_name: "Admin",
        root_admin: true,
        language: "en",
        password
      })
    });

    const data = await res.json();
    if (data.errors) return reply(`${JSON.stringify(data.errors[0], null, 2)}`);

    const user = data.attributes;

    const ram = 0;
    const disk = 0;
    const cpu = 0;
    const server = { id: "N/A" };

    const domainTeks = (global.domain || "").replace(/https?:\/\//g, "");
    const tampilDomain = `<spoiler>${domainTeks}</spoiler>`;

    const teks = `
✅ <b>Berhasil membuat akun panel</b>

📡 <b>Server ID:</b> <code>${server.id}</code>
👤 <b>Username:</b> <code>${user.username}</code>
🔐 <b>Password:</b> <code>${password}</code>
🗓️ <b>Tanggal Aktivasi:</b> ${global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString()}

⚙️ <b>Spesifikasi server panel:</b>
- RAM: ${ram === 0 ? "Unlimited" : ram / 1000 + "GB"}
- Disk: ${disk === 0 ? "Unlimited" : disk / 1000 + "GB"}
- CPU: ${cpu === 0 ? "Unlimited" : cpu + "%"}
- Panel: ${tampilDomain}

📝 <b>Rules pembelian panel:</b>
- Masa aktif 30 hari
- Data bersifat pribadi, simpan dengan aman
- Garansi berlaku 15 hari (1x replace)
- Klaim garansi wajib menyertakan bukti chat pembelian
`;

    if (msg.isGroup) {
      await reply("✅ Berhasil membuat akun panel!\n📩 Data akun telah dikirim ke private chat.");
    }

    await reply(teks, { parseMode: "html", jid: chatTarget });

  } catch (err) {
    console.error(err);
    await reply("⚠️ Terjadi kesalahan saat membuat akun panel.");
  }
}
break;

case "deladmin": {
  if (!isOwner) return messOwner()
  if (!argText) return reply(`Input ID User!\n\nContoh penggunaan:\n<code>${cmd}</code> 13`);

  try {
    const res = await fetch(`${domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    });
    const data = await res.json();
    const users = data.data;

    const targetAdmin = users.find(e => e.attributes.id == argText && e.attributes.root_admin === true);
    if (!targetAdmin) return reply("Gagal menghapus admin!\nID user tidak ditemukan.");

    const idadmin = targetAdmin.attributes.id;
    const username = targetAdmin.attributes.username;

    const delRes = await fetch(`${domain}/api/application/users/${idadmin}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`
      }
    });

    if (!delRes.ok) {
      const errData = await delRes.json();
      return reply(`Gagal menghapus admin!\n${JSON.stringify(errData.errors[0], null, 2)}`);
    }

    await reply(`✅ Berhasil menghapus admin panel.\nNama User: ${capital(username)}`);

  } catch (err) {
    console.error(err);
    await reply("⚠️ Terjadi kesalahan saat menghapus akun admin.");
  }
}
break;

case "listadmin": {
  if (!isOwner) return messOwner()

  try {
    const response = await fetch(`${global.domain}/api/application/users`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${global.apikey}`
      }
    });
    const result = await response.json();
    const users = result.data || [];

    const adminUsers = users.filter(u => u.attributes.root_admin === true);
    if (adminUsers.length === 0) return reply("⚠️ <b>Tidak ada admin panel!</b>");

    let teks = `<b>Total admin panel:</b> ${adminUsers.length}\n`;
    for (const admin of adminUsers) {
      const u = admin.attributes;
      teks += `
• <b>ID:</b> <code>${u.id}</code>
• <b>Nama:</b> ${u.first_name} ${u.last_name || ""}
• <b>Username:</b> ${u.username}
• <b>Dibuat:</b> ${u.created_at?.split("T")[0] || "-"}\n`;
    }

    await client.sendMessage(msg.chatId, { message: teks, parseMode: "html", replyTo: msg.id });

  } catch (err) {
    console.error("Error listing admin panel:", err);
    await reply("⚠️ <b>Terjadi kesalahan saat mengambil data admin.</b>");
  }
}
break;

case "addseller": {
if (!isOwner) return messOwner()
        
let targetId = null;

if (msg.replyToMsgId) {
    const repliedMsg = await msg.getReplyMessage();
    if (repliedMsg && repliedMsg.senderId) targetId = repliedMsg.senderId.toString();
} else if (argText) {
    const input = argText.trim();
    
    if (!isNaN(input) && input.length >= 5) {
        targetId = input;
    } else {
        try {
            const username = input.startsWith('@') ? input : `@${input}`;
            const entity = await client.getInputEntity(username);
            const sender = await client.getEntity(entity);
            targetId = sender.id.toString();
        } catch (e) {
            console.log(`[Add Seller Resolve Error]: ${e?.message || e}`);
        }
    }
}

if (!targetId) {
    return reply(`Masukkan ID, @username, atau balas pesan pengguna.\n\nContoh: <code>${cmd}addseller @username</code> atau <code>${cmd} 123456789</code>`);
}

if (sellerList.includes(targetId)) {
  return reply(`⚠️ Pengguna <code>${targetId}</code> sudah ada di daftar Seller.`);
}

if (targetId === me.id.toString()) return reply("⚠️ Bot tidak bisa dijadikan Seller.");
if (targetId === global.ownerID?.toString()) return reply("⚠️ Owner sudah memiliki akses penuh.");

sellerList.push(targetId);
await fs.writeFileSync("./data-sellerlist.json", JSON.stringify(sellerList, null, 2))

try {
  const userEntity = await client.getEntity(targetId);
  const username = userEntity.username ? `@${userEntity.username}` : userEntity.firstName || "Pengguna";
  await reply(`✅ Pengguna <b>${username}</b> (<code>${targetId}</code>) berhasil ditambahkan sebagai Seller.`);
} catch (err) {
  await reply(`✅ ID <code>${targetId}</code> berhasil ditambahkan ke daftar Seller.`);
}
break;
}


case "resetseller": {
if (!isOwner) return messOwner()
sellerList = [];
await fs.writeFileSync("./data-sellerlist.json", JSON.stringify(sellerList, null, 2))
await reply("✅ Semua reseller panel telah dihapus.");
break;
}      

case "delseller": {
if (!isOwner) return messOwner()
        
let targetId = null;

if (msg.replyToMsgId) {
    const repliedMsg = await msg.getReplyMessage();
    if (repliedMsg && repliedMsg.senderId) targetId = repliedMsg.senderId.toString();
} else if (argText) {
    const input = argText.trim();
    
    if (!isNaN(input) && input.length >= 5) {
        targetId = input;
    } else {
        try {
            const username = input.startsWith('@') ? input : `@${input}`;
            const entity = await client.getInputEntity(username);
            const sender = await client.getEntity(entity);
            targetId = sender.id.toString();
        } catch (e) {
            console.log(`[Del Seller Resolve Error]: ${e?.message || e}`);
        }
    }
}

if (!targetId) {
    return reply(`Masukkan ID, @username, atau balas pesan pengguna.\n\nContoh: <code>${cmd} @username</code> atau <code>${cmd} 123456789</code>`);
}

if (!sellerList.includes(targetId)) {
  return reply(`⚠️ Pengguna <code>${targetId}</code> tidak ada di daftar Seller.`);
}

sellerList = sellerList.filter((id) => id !== targetId);
await fs.writeFileSync("./data-sellerlist.json", JSON.stringify(sellerList, null, 2))

try {
  const userEntity = await client.getEntity(targetId);
  const username = userEntity.username ? `@${userEntity.username}` : userEntity.firstName || "Pengguna";
  await reply(`✅ Pengguna <b>${username}</b> (<code>${targetId}</code>) dihapus dari daftar Seller.`);
} catch {
  await reply(`✅ ID <code>${targetId}</code> berhasil dihapus dari daftar Seller.`);
}
break;
}

case "listseller": {
if (!isOwner) return messOwner()
if (sellerList.length === 0) return reply("✅ Tidak ada pengguna dalam daftar Seller.");

let txt = "\n";
for (const [i, id] of sellerList.entries()) {
  try {
    const user = await client.getEntity(id);
    const username = user.username ? `@${user.username}` : user.firstName || "(Tanpa Nama)";
    txt += `${i + 1}. ${username} (<code>${id}</code>)\n`;
  } catch {
    txt += `${i + 1}. [Tidak diketahui] (<code>${id}</code>)\n`;
  }
}
await reply(txt);
break;
}

case "subdomain": case "domain": case "subdo": {

if (!isOwner) return messOwner()

const dom = global.subdomain ? Object.keys(global.subdomain) : [];

if (!argText) {
    if (dom.length === 0) {
        return reply("⚠️ Tidak ada domain yang tersedia! Harap konfigurasi <code>global.subdomain</code>.");
    }

    let teks = "🌐 Daftar Domain Tersedia:\n\n";
    dom.forEach((d, i) => {
        teks += `${i + 1}. ${d}\n`;
    });
    
    teks += `\nCara membuat subdomain:\n<code>${cmd} [nomor] hostname|ipvps</code>`;

    return reply(teks);
}

const parts = argText.split(" "); 
const domainNumber = parts[0];
const hostAndIpText = parts.slice(1).join(" ").trim();

const domainIndex = Number(domainNumber) - 1;

if (isNaN(domainIndex) || domainIndex < 0 || domainIndex >= dom.length) {
    return reply(`Domain tidak ditemukan! Masukkan nomor domain yang valid.\n\nContoh: <code>${cmd} 1 panel|1.2.3.4</code>`);
}

const tldnya = dom[domainIndex];

if (!hostAndIpText || !hostAndIpText.includes("|")) {
     return reply("⚠️ Hostname / IP tidak valid!\nContoh: <code>1 panel|1.2.3.4</code>");
}

const [host, ip] = hostAndIpText.split("|").map(str => str.trim());

if (!host || !ip) {
    return reply("⚠️ Hostname / IP tidak boleh kosong setelah pemisah '|'!");
}

const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
if (!ipRegex.test(ip)) {
     return reply("⚠️ Format IP Address tidak valid!");
}

async function subDomainAPI(subHost, ipAddress, tldConfig) {
    return new Promise((resolve) => {
        axios.post(
            `https://api.cloudflare.com/client/v4/zones/${tldConfig.zone}/dns_records`,
            {
                type: "A",
                name: `${subHost.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                content: ipAddress.replace(/[^0-9.]/gi, ""),
                ttl: 3600,
                priority: 10,
                proxied: false,
            },
            {
                headers: {
                    Authorization: `Bearer ${tldConfig.apitoken}`,
                    "Content-Type": "application/json",
                },
            }
        ).then(response => {
            let res = response.data;
            if (res.success) {
                resolve({
                    success: true,
                    name: res.result?.name,
                    ip: res.result?.content
                });
            } else {
                let errorMsg = res.errors?.[0]?.message || "Gagal membuat subdomain.";
                resolve({ success: false, error: errorMsg });
            }
        }).catch(error => {
            let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan pada API!";
            resolve({ success: false, error: errorMsg });
        });
    });
}

await reply("⏳ Memproses pembuatan Subdomain (Panel & Node)...");

const tldConfig = global.subdomain[tldnya];
const domnode = `node-${global.getRandom(5).toLowerCase()}`;

let teksResult = "✅ Subdomain berhasil dibuat!\n\n";
teksResult += `🌍 IP Address: <code>${ip}</code>\n`;

for (let i = 0; i < 2; i++) {
    let subHost = i === 0 ? host.toLowerCase() : domnode;
    try {
        let result = await subDomainAPI(subHost, ip, tldConfig);
        if (result.success) {
            teksResult += `${i === 0 ? "📮 Panel" : "📡 Node"}: <code>${result.name}</code>\n`;
        } else {
            return reply(`❌ Gagal membuat ${i === 0 ? "Panel" : "Node"} Subdomain: ${result.error}`);
        }
    } catch (err) {
        return reply("❌ Error saat eksekusi: " + err.message);
    }
}

await reply(teksResult);
}
break;

    

case "installpanel": {
  if (!isOwner) return messOwner();

  if (!text)
    return client.sendMessage(msg.chatId, {
      message: `Format Salah!\n\nContoh penggunaan:\n<code>${cmd}</code> ipvps|pwvps|panel.com|node.com|ramserver`,
      parseMode: "html",
    });

  let vii = text.split("|");
  if (vii.length < 5)
    return client.sendMessage(msg.chatId, {
      message: `Format Salah!\n\nContoh penggunaan:\n<code>${cmd}</code> ipvps|pwvps|panel.com|node.com|ramserver`,
      parseMode: "html",
    });

  const { Client: SSHClient } = require("ssh2");
  const ssh = new SSHClient();

  const ipVps = vii[0];
  const pwVps = vii[1];
  const domainpanel = vii[2];
  const domainnode = vii[3];
  const ramserver = vii[4];
  const jids = msg.chatId;
  const passwordPanel = "admin001";
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

  const connSettings = {
    host: ipVps,
    port: vii[5] ? parseInt(vii[5]) : 22,
    username: "root",
    password: pwVps,
  };

  async function instalPanel() {
    ssh.exec(commandPanel, (err, stream) => {
      if (err) {
        return client.sendMessage(jids, {
          message: `Gagal menjalankan instalasi panel: ${err.message}`,
        });
      }

      stream
        .on("data", async (data) => {
          const str = data.toString();
          console.log("Panel:", str);

          if (str.includes("Input 0-6")) stream.write("0\n");
          if (str.includes("(y/N)")) stream.write("y\n");
          if (str.includes("Database name (panel)")) stream.write("\n");
          if (str.includes("Database username (pterodactyl)")) stream.write("admin\n");
          if (str.includes("Password (press enter")) stream.write("admin\n");
          if (str.includes("Select timezone")) stream.write("Asia/Jakarta\n");
          if (str.includes("Provide the email address")) stream.write("admin@gmail.com\n");
          if (str.includes("Email address for the initial admin account")) stream.write("admin@gmail.com\n");
          if (str.includes("Username for the initial admin account")) stream.write("admin\n");
          if (str.includes("First name for the initial admin account")) stream.write("admin\n");
          if (str.includes("Last name for the initial admin account")) stream.write("admin\n");
          if (str.includes("Password for the initial admin account")) stream.write(`${passwordPanel}\n`);
          if (str.includes("Set the FQDN of this panel")) stream.write(`${domainpanel}\n`);
          if (str.includes("Do you want to automatically configure UFW")) stream.write("y\n");
          if (str.includes("Do you want to automatically configure HTTPS")) stream.write("y\n");
          if (str.includes("Select the appropriate number")) stream.write("1\n");
          if (str.includes("I agree that this HTTPS request")) stream.write("y\n");
          if (str.includes("Proceed anyways")) stream.write("y\n");
          if (str.includes("(yes/no)")) stream.write("y\n");
          if (str.includes("Initial configuration completed")) stream.write("y\n");
          if (str.includes("Still assume SSL?")) stream.write("y\n");
          if (str.includes("Please read the Terms of Service")) stream.write("y\n");
          if (str.includes("(A)gree/(C)ancel")) stream.write("A\n");
        })
        .stderr.on("data", (data) => {
          console.error("Panel Error:", data.toString());
          client.sendMessage(jids, {
            message: `Error pada instalasi Panel:\n${data.toString()}`,
          });
        })
        .on("close", () => instalWings());
    });
  }

  async function instalWings() {
    ssh.exec(commandPanel, (err, stream) => {
      if (err) {
        return client.sendMessage(jids, {
          message: `Gagal memulai instalasi Wings: ${err.message}`,
        });
      }

      stream
        .on("data", (data) => {
          const str = data.toString();
          console.log("Wings:", str);
          if (str.includes("Input 0-6")) stream.write("1\n");
          if (str.includes("(y/N)")) stream.write("y\n");
          if (str.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
          if (str.includes("Database host username")) stream.write("admin\n");
          if (str.includes("Database host password")) stream.write("admin\n");
          if (str.includes("Set the FQDN")) stream.write(`${domainnode}\n`);
          if (str.includes("Enter email address for Let")) stream.write("admin@gmail.com\n");
        })
        .stderr.on("data", (data) => {
          console.error("Wings Error:", data.toString());
          client.sendMessage(jids, {
            message: `Error pada instalasi Wings:\n${data.toString()}`,
          });
        })
        .on("close", () => InstallNodes());
    });
  }

  async function InstallNodes() {
    ssh.exec(
      "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)",
      (err, stream) => {
        if (err) throw err;

        stream
          .on("data", (data) => {
            const str = data.toString();
            console.log("Node:", str);
            if (str.includes("Masukkan nama lokasi")) stream.write("Singapore\n");
            if (str.includes("Masukkan deskripsi lokasi")) stream.write("Node By Skyzo\n");
            if (str.includes("Masukkan domain")) stream.write(`${domainnode}\n`);
            if (str.includes("Masukkan nama node")) stream.write("Skyzopedia\n");
            if (str.includes("Masukkan RAM")) stream.write(`${ramserver}\n`);
            if (str.includes("Masukkan jumlah maksimum disk")) stream.write(`${ramserver}\n`);
            if (str.includes("Masukkan Locid")) stream.write("1\n");
          })
          .stderr.on("data", (data) => {
            console.error("Node Error:", data.toString());
            client.sendMessage(jids, {
              message: `Error pada instalasi Node:\n${data.toString()}`,
            });
          })
          .on("close", async () => {
            const teks = `
<b>✅ Install Panel Berhasil!</b>

<b>📦 Detail Akun Panel Kamu:</b>
👤 <b>Username:</b> <code>admin</code>
🔐 <b>Password:</b> <code>${passwordPanel}</code>
🌐 <spoiler>${domainpanel}</spoiler>

<b>⚙️ Silakan atur allocation & ambil token node</b> pada node yang sudah dibuat oleh bot.

<b>🚀 Cara menjalankan wings:</b>
<code>${global.prefix}startwings ${ipVps}|${pwVps}|tokennode</code>
`;

            await client.sendMessage(jids, {
              message: teks,
              parseMode: "html",
            });
            ssh.end();
          });
      }
    );
  }

  ssh.on("ready", async () => {
    await client.sendMessage(jids, {
      message: `🛠️ Proses instalasi panel sedang berjalan 🚀

📡 IP Address: ${ipVps}
🌐 Domain Panel: <spoiler>${domainpanel}</spoiler>

⏳ Mohon tunggu sekitar 10–20 menit hingga proses instalasi selesai.
Anda akan mendapatkan notifikasi setelah panel berhasil terpasang.`,
      parseMode: "html",
      replyTo: msg.id,
    });

    ssh.exec("", (err, stream) => {
      if (err) throw err;
      stream.on("close", async () => instalPanel()).on("data", async (data) => {
        await stream.write("\t");
        await stream.write("\n");
        await console.log(data.toString());
        });
    })
  });

  ssh.on("error", (err) => {
    console.error("SSH Connection Error:", err);
    client.sendMessage(jids, {
      message: `Gagal terhubung ke server: ${err.message}`,
      replyTo: msg.id,
    });
  });

  ssh.connect(connSettings);
}
break;


case "startwings":
case "configurewings": {
    if (!isOwner) return messOwner()
    let t = text.split("|");
    if (t.length < 3) return reply(`Format Salah!\n\nContoh penggunaan:\n<code>${cmd}</code> ipvps|pwvps|token`);

    let [ipvps, passwd, token] = t
    const connSettings = { host: ipvps, port: 22, username: "root", password: passwd };
    const ssh = new SSHClient();

    ssh.on("ready", () => {
        ssh.exec(`${token} && systemctl start wings`, (err, stream) => {
            if (err) return client.sendMessage(msg.chatId, { message: "Gagal menjalankan perintah di VPS", replyTo: msg.id });

            stream.on("close", async () => {
                await client.sendMessage(msg.chatId, { message: "✅ Wings node Pterodactyl berhasil dijalankan!", replyTo: msg.id });
                ssh.end();
            }).on("data", data => stream.write("y\n\n"))
              .stderr.on("data", data => {
                  console.log("STDERR:", data.toString());
                  client.sendMessage(msg.chatId, { message: `Terjadi error saat eksekusi:\n${data.toString()}`, replyTo: msg.id });
              });
        });
    }).on("error", err => {
        console.log("Connection Error:", err.message);
        client.sendMessage(msg.chatId, { message: "Gagal terhubung ke VPS: IP atau password salah.", replyTo: msg.id });
    }).connect(connSettings);
}
break;
          
case "eval":
case "ev": {
  if (!isOwner) return;
  if (!argText) return client.sendMessage(m.chat.id, { message: "Masukkan kode JavaScript untuk dievaluasi." });

  try {
    let result = await eval(`(async () => { ${argText} })()`);
    if (typeof result !== "string")
      result = require("util").inspect(result, { depth: 1 });

    if (result.length > 4000) {
      const fs = require("fs");
      const filePath = "./eval_result.txt";
      fs.writeFileSync(filePath, result);

      await client.sendFile(msg.chatId, {
        file: filePath,
        caption: "✅ Eval berhasil (hasil dikirim sebagai file)",
      });

      fs.unlinkSync(filePath);
    } else {
      await client.sendMessage(msg.chatId, {
        message: `<b>✅ Eval berhasil:</b>\n<pre>${result}</pre>`,
        parseMode: "html",
      });
    }
  } catch (err) {
    await client.sendMessage(msg.chatId, {
      message: `<b>❌ Eval error:</b>\n<pre>${err}</pre>`,
      parseMode: "html",
    });
  }
  break;
}

default:
break;

}
} catch (err) {
console.error("Error:", err);
}
};


let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`• File update: ${__filename}`);
  delete require.cache[file];
  require(file);
});